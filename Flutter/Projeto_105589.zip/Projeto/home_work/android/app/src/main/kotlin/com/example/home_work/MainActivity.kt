package com.example.home_work

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
