01  MyFirst application

Myapp.zip - the application generated when creating a empty flutter project - the counter 
02 Management of  views and routing in an application

RedBlue.zip - basic application using simple routing between a REd and a Blue view

	simple example with two "screens": a Red and a Blue
	
	application starts with Blue screen
	
		using a button can change to Red screen
		
	stack behaviour ( red presents a arrow to go back )
		
note: I will add alls new widgets directly in libs 


RedBlueTab.zip - basic application using a tabbed application Red, Blue and Yellow view - based on previous example

Based on https://flutter.dev/docs/cookbook/design/tabs 

"When a tab is selected, it needs to display content. You can create tabs using the TabBar widget. In this example, create a TabBar with three Tab widgets and place it within an AppBar."
03 share state in application

Counter_plain.zip - the plain counter example
Counter_IW.zip  -  state is kept by a InheritingWidget
Counter_CN.zip  -  state is kept by a ChangNofier
Counter_BLOC.zip  -  state is kept by a bloc using the flutter_bloc package
Cart_BLOC.zip	- typical cart application (simplistic) using a BLOC
Cart_2BLOC.zip	- typical cart application (simplistic) using a 2 BLOC

Some related resources 

https://pub.dev/packages/flutter_bloc

https://flutter.dev/docs/development/data-and-backend/state-mgmt/options 

 https://www.netguru.com/codestories/flutter-bloc 

Flutter Provider Examples – Change, Future, Stream
https://codetober.com/flutter-provider-examples/ 

Making sense of all those Flutter Providers
Suragch - Oct 30, 2019 · 10 min read
https://medium.com/flutter-community/making-sense-all-of-those-flutter-providers-e842e18f45dd 

Flutter — How does MultiProvider work with providers of the same type ?
https://medium.com/codespace69/flutter-how-does-multiprovider-work-with-providers-of-the-same-type-bd632bd2cbad 

